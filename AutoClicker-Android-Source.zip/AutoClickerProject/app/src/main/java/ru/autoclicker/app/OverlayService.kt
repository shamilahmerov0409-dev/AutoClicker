package ru.autoclicker.app

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var marker: View? = null
    private var markerParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var counterView: TextView? = null
    private var controls: LinearLayout? = null
    private var collapsed = false
    private val handler = Handler(Looper.getMainLooper())
    private var index = 0
    private var taps = 0L
    private var paused = false
    private val points = mutableListOf<Pair<Float, Float>>()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val interval get() = prefs.getLong("interval", 500L).coerceIn(50, 60000)
    private val limit get() = prefs.getLong("count", 0L).coerceAtLeast(0)

    private val loop = object : Runnable {
        override fun run() {
            if (!isRunning || paused) return
            val service = ClickAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this@OverlayService, "Сначала включи службу специальных возможностей", Toast.LENGTH_LONG).show()
                setRunning(false)
                return
            }
            if (points.isEmpty()) {
                Toast.makeText(this@OverlayService, "Добавь хотя бы одну точку кнопкой ⊕", Toast.LENGTH_SHORT).show()
                setRunning(false)
                return
            }
            if (limit > 0 && taps >= limit) {
                setRunning(false)
                Toast.makeText(this@OverlayService, "Лимит нажатий достигнут", Toast.LENGTH_SHORT).show()
                return
            }
            val p = points[index % points.size]
            index++
            taps++
            updateCounter()
            service.tap(p.first, p.second) {
                if (isRunning && !paused) handler.postDelayed(this, interval)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
        showPanel()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 14): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun iconButton(icon: String, description: String, color: Int, action: () -> Unit): TextView {
        val button = TextView(this).apply {
            text = icon
            contentDescription = description
            gravity = Gravity.CENTER
            textSize = 27f
            typeface = Typeface.DEFAULT
            setTextColor(Color.WHITE)
            background = rounded(color, 12)
            isClickable = true
            isFocusable = false
            setPadding(0, 0, 0, 0)
            elevation = dp(2).toFloat()
        }
        val lp = LinearLayout.LayoutParams(dp(54), dp(50)).apply { topMargin = dp(5); bottomMargin = dp(5) }
        button.setOnClickListener {
            // Clear visual feedback that the touch was received.
            button.animate().cancel()
            button.alpha = 0.55f
            button.scaleX = 0.92f
            button.scaleY = 0.92f
            button.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
            action()
        }
        button.tag = lp
        return button
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(7), dp(8), dp(7), dp(8))
            background = rounded(0xF21B1B25.toInt(), 20)
            clipToPadding = false
        }
        val header = TextView(this).apply {
            text = "Auto\nClicker"
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(2), dp(5), dp(2), dp(8))
            contentDescription = "Перетащить панель"
        }
        box.addView(header, LinearLayout.LayoutParams(dp(64), LinearLayout.LayoutParams.WRAP_CONTENT))
        header.setOnTouchListener(dragListener())

        counterView = TextView(this).apply {
            text = "0 · 0"
            gravity = Gravity.CENTER
            textSize = 11f
            setTextColor(0xFFD8D2FF.toInt())
            contentDescription = "Счётчик нажатий и точек"
        }
        box.addView(counterView, LinearLayout.LayoutParams(dp(64), dp(34)))

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        controls?.addView(iconButton("▶", "Старт", 0xFF218C43.toInt()) {
            if (points.isEmpty()) {
                Toast.makeText(this, "Сначала добавь точку кнопкой ⊕", Toast.LENGTH_SHORT).show()
            } else {
                paused = false
                setRunning(true)
            }
        }, LinearLayout.LayoutParams(dp(54), dp(50)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        controls?.addView(iconButton("Ⅱ", "Пауза", 0xFF6650C8.toInt()) {
            paused = true
            handler.removeCallbacks(loop)
        }, LinearLayout.LayoutParams(dp(54), dp(50)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        controls?.addView(iconButton("■", "Стоп", 0xFFB83232.toInt()) {
            paused = false
            setRunning(false)
            taps = 0
            index = 0
            updateCounter()
        }, LinearLayout.LayoutParams(dp(54), dp(50)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        controls?.addView(iconButton("⊕", "Добавить точку", 0xFF8E44AD.toInt()) { showMarker() },
            LinearLayout.LayoutParams(dp(54), dp(50)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        controls?.addView(iconButton("−", "Удалить последнюю точку", 0xFF6650C8.toInt()) {
            if (points.isNotEmpty()) points.removeAt(points.lastIndex)
            updateCounter()
            Toast.makeText(this, if (points.isEmpty()) "Все точки удалены" else "Точка удалена", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(dp(54), dp(50)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        controls?.addView(iconButton("×", "Закрыть панель", 0xFF42424B.toInt()) {
            setRunning(false)
            paused = false
            stopSelf()
        }, LinearLayout.LayoutParams(dp(54), dp(50)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        box.addView(controls)

        val toggle = TextView(this).apply {
            text = "⌃"
            gravity = Gravity.CENTER
            textSize = 30f
            setTextColor(Color.WHITE)
            background = rounded(0xFF30303B.toInt(), 28)
            contentDescription = "Свернуть или развернуть панель"
        }
        box.addView(toggle, LinearLayout.LayoutParams(dp(58), dp(58)).apply { topMargin = dp(8) })
        toggle.setOnClickListener {
            collapsed = !collapsed
            counterView?.visibility = if (collapsed) View.GONE else View.VISIBLE
            controls?.visibility = if (collapsed) View.GONE else View.VISIBLE
            toggle.text = if (collapsed) "⌄" else "⌃"
            toggle.animate().cancel()
            toggle.alpha = 0.55f
            toggle.animate().alpha(1f).setDuration(180).start()
            panel?.let { try { wm.updateViewLayout(it, panelParams) } catch (_: Exception) {} }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels - dp(80)).coerceAtLeast(0)
            y = dp(120)
        }
        panel = box
        panelParams = params
        try { wm.addView(box, params) } catch (_: Exception) { stopSelf() }
        updateCounter()
    }

    private fun updateCounter() {
        counterView?.text = "$taps · ${points.size}"
    }

    private fun showMarker() {
        marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        val v = TargetMarkerView(this)
        val p = WindowManager.LayoutParams(
            dp(76), dp(76), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels / 2 - dp(38)).coerceAtLeast(0)
            y = (resources.displayMetrics.heightPixels / 2 - dp(38)).coerceAtLeast(0)
        }
        marker = v
        markerParams = p
        var downX = 0f
        var downY = 0f
        var originX = 0
        var originY = 0
        v.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY; originX = p.x; originY = p.y; true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = originX + (event.rawX - downX).toInt()
                    p.y = originY + (event.rawY - downY).toInt()
                    try { wm.updateViewLayout(view, p) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = abs(event.rawX - downX) + abs(event.rawY - downY)
                    if (moved < dp(10)) {
                        // Accessibility gestures use screen coordinates. Save the center of the target.
                        points.add((p.x + p.width / 2f) to (p.y + p.height / 2f))
                        updateCounter()
                        try { wm.removeView(view) } catch (_: Exception) {}
                        marker = null
                        Toast.makeText(this, "Точка добавлена: ${points.size}", Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> true
            }
        }
        try { wm.addView(v, p) } catch (_: Exception) { marker = null }
    }

    private fun dragListener(): View.OnTouchListener {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        return View.OnTouchListener { _, e ->
            val p = panelParams ?: return@OnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; true }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (ox + (e.rawX - sx).toInt()).coerceAtLeast(0)
                    p.y = (oy + (e.rawY - sy).toInt()).coerceAtLeast(0)
                    try { panel?.let { wm.updateViewLayout(it, p) } } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
    }

    override fun onDestroy() {
        setRunning(false)
        handler.removeCallbacksAndMessages(null)
        marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        marker = null; panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        @Volatile private var runningState = false
        val isRunning: Boolean get() = runningState
        fun setRunning(value: Boolean) { runningState = value }
    }

    private fun setRunning(value: Boolean) {
        OverlayService.setRunning(value)
        handler.removeCallbacks(loop)
        if (value && !paused) handler.post(loop)
    }
}

private class TargetMarkerView(context: android.content.Context) : View(context) {
    private val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 255, 40); style = Paint.Style.STROKE; strokeWidth = 4f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x6630FF50; style = Paint.Style.FILL }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 255, 40); strokeWidth = 3f }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f; val r = width.coerceAtMost(height) * 0.39f
        canvas.drawCircle(cx, cy, r, fill)
        canvas.drawCircle(cx, cy, r, outer)
        canvas.drawLine(cx - r, cy, cx + r, cy, cross)
        canvas.drawLine(cx, cy - r, cx, cy + r, cross)
    }
}
