package ru.autoclicker.app

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var marker: View? = null
    private var markerParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var counterView: TextView? = null
    private var statusView: TextView? = null
    private var controls: LinearLayout? = null
    private var collapsed = false
    private val handler = Handler(Looper.getMainLooper())
    private var index = 0
    private var taps = 0L
    private var paused = false
    private var gestureInFlight = false
    private var consecutiveFailures = 0
    private var runToken = 0L
    private val points = mutableListOf<Pair<Float, Float>>()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val interval get() = prefs.getLong("interval", 500L).coerceIn(50, 60000)
    private val limit get() = prefs.getLong("count", 0L).coerceAtLeast(0)

    private val loop = object : Runnable {
        override fun run() {
            if (!isRunning || paused) return
            // Do not dispatch a new accessibility gesture while the user is touching
            // the floating panel. dispatchGesture cancels touches already in progress,
            // which previously made Pause/Stop appear to require two taps.
            if (userInteracting) return
            val service = ClickAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this@OverlayService, "Сначала включи службу специальных возможностей", Toast.LENGTH_LONG).show()
                setRunning(false)
                return
            }
            if (points.isEmpty()) {
                Toast.makeText(this@OverlayService, "Добавь хотя бы одну точку кнопкой ⊕", Toast.LENGTH_SHORT).show()
                setRunning(false)
                return
            }
            if (limit > 0 && taps >= limit) {
                setRunning(false)
                Toast.makeText(this@OverlayService, "Лимит нажатий достигнут", Toast.LENGTH_SHORT).show()
                return
            }
            if (gestureInFlight) {
                handler.postDelayed(this, 20L)
                return
            }
            val p = points[index % points.size]
            val token = runToken
            gestureInFlight = true
            val accepted = service.tap(p.first, p.second) { completed ->
                if (token != runToken) return@tap
                gestureInFlight = false
                if (completed) {
                    taps++
                    index++
                    consecutiveFailures = 0
                    updateCounter()
                } else {
                    consecutiveFailures++
                    if (consecutiveFailures >= 3) {
                        setRunning(false)
                        Toast.makeText(this@OverlayService,
                            "Android отклоняет нажатия. Кликер остановлен; проверь службу специальных возможностей.",
                            Toast.LENGTH_LONG).show()
                        return@tap
                    }
                }
                if (isRunning && !paused && !userInteracting) handler.postDelayed(this, interval)
            }
            if (!accepted) {
                // dispatchGesture can reject a request without delivering a callback.
                // tap() invokes the callback on rejection; don't leave the loop stuck.
            }
        }
    }

    // While any panel button is pressed, suspend scheduling of new dispatchGesture calls.
    // The delayed reset lets Android deliver ACTION_UP/onClick before automatic tapping resumes.
    private var userInteracting = false
    private var markerPointIndex: Int? = null
    private var screenOffsetX = 0f
    private var screenOffsetY = 0f
    private var screenOffsetKnown = false
    private val interactionReset = Runnable {
        userInteracting = false
        if (isRunning && !paused) {
            handler.removeCallbacks(loop)
            handler.post(loop)
        }
    }

    override fun onCreate() {
        super.onCreate()
        serviceInstance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
        showPanel()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 14): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun iconButton(icon: String, description: String, color: Int, action: () -> Unit): TextView {
        val button = TextView(this).apply {
            text = icon
            contentDescription = description
            gravity = Gravity.CENTER
            textSize = 22f
            typeface = Typeface.DEFAULT
            setTextColor(Color.WHITE)
            background = rounded(color, 12)
            isClickable = true
            isFocusable = false
            setPadding(0, 0, 0, 0)
            elevation = dp(2).toFloat()
        }
        val lp = LinearLayout.LayoutParams(dp(42), dp(38)).apply { topMargin = dp(2); bottomMargin = dp(2) }
        button.setOnClickListener {
            // Clear visual feedback that the touch was received.
            button.animate().cancel()
            button.alpha = 0.55f
            button.scaleX = 0.92f
            button.scaleY = 0.92f
            button.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
            action()
        }
        button.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    userInteracting = true
                    handler.removeCallbacks(loop)
                    handler.removeCallbacks(interactionReset)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(interactionReset)
                    handler.postDelayed(interactionReset, 180L)
                }
            }
            // Return false so TextView still handles the touch and fires its click listener.
            false
        }
        button.tag = lp
        return button
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = rounded(0xF21B1B25.toInt(), 20)
            clipToPadding = false
        }
        val header = TextView(this).apply {
            text = "Auto\nClicker"
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(dp(2), dp(5), dp(2), dp(8))
            contentDescription = "Перетащить панель"
        }
        box.addView(header, LinearLayout.LayoutParams(dp(48), LinearLayout.LayoutParams.WRAP_CONTENT))
        header.setOnTouchListener(dragListener())

        counterView = TextView(this).apply {
            text = "0:0"
            gravity = Gravity.CENTER
            textSize = 10f
            setTextColor(0xFFD8D2FF.toInt())
            contentDescription = "Счётчик нажатий и точек"
        }
        box.addView(counterView, LinearLayout.LayoutParams(dp(48), dp(25)))

        statusView = TextView(this).apply {
            text = "НЕТ СЛУЖ."
            gravity = Gravity.CENTER
            textSize = 8f
            setTextColor(0xFFBDBDC8.toInt())
            contentDescription = "Состояние кликера"
            setPadding(0, 0, 0, dp(2))
        }
        box.addView(statusView, LinearLayout.LayoutParams(dp(58), dp(17)))

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        controls?.addView(iconButton("▶", "Старт", 0xFF218C43.toInt()) {
            if (ClickAccessibilityService.instance == null) {
                Toast.makeText(this, "Сначала включи службу специальных возможностей", Toast.LENGTH_LONG).show()
            } else if (points.isEmpty()) {
                Toast.makeText(this, "Сначала добавь точку кнопкой ⊕", Toast.LENGTH_SHORT).show()
            } else if (!isRunning) {
                paused = false
                consecutiveFailures = 0
                setRunning(true)
            } else if (paused) {
                paused = false
                setRunning(true)
            } else {
                Toast.makeText(this, "Кликер уже работает", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(dp(42), dp(38)).apply { topMargin = dp(2); bottomMargin = dp(2) })
        controls?.addView(iconButton("Ⅱ", "Пауза", 0xFF6650C8.toInt()) {
            if (isRunning && !paused) {
                paused = true
                handler.removeCallbacks(loop)
                setMarkerTouchable(true)
                updateStatus()
                Toast.makeText(this, "Пауза", Toast.LENGTH_SHORT).show()
            } else if (paused) {
                Toast.makeText(this, "Уже на паузе", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(dp(42), dp(38)).apply { topMargin = dp(2); bottomMargin = dp(2) })
        controls?.addView(iconButton("■", "Стоп", 0xFFB83232.toInt()) {
            paused = false
            // Do not remove all Handler messages: the pending touch-release guard must
            // still clear userInteracting after this Stop click.
            handler.removeCallbacks(loop)
            setRunning(false)
            gestureInFlight = false
            consecutiveFailures = 0
            taps = 0
            index = 0
            updateCounter()
            Toast.makeText(this, "Остановлено", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(dp(42), dp(38)).apply { topMargin = dp(2); bottomMargin = dp(2) })
        controls?.addView(iconButton("⊕", "Добавить точку", 0xFF8E44AD.toInt()) { showMarker() },
            LinearLayout.LayoutParams(dp(42), dp(38)).apply { topMargin = dp(2); bottomMargin = dp(2) })
        controls?.addView(iconButton("−", "Удалить последнюю точку", 0xFF6650C8.toInt()) {
            removeLastPoint()
        }, LinearLayout.LayoutParams(dp(42), dp(38)).apply { topMargin = dp(2); bottomMargin = dp(2) })
        controls?.addView(iconButton("×", "Закрыть панель", 0xFF42424B.toInt()) {
            setRunning(false)
            paused = false
            stopSelf()
        }, LinearLayout.LayoutParams(dp(42), dp(38)).apply { topMargin = dp(2); bottomMargin = dp(2) })
        box.addView(controls)

        val toggle = TextView(this).apply {
            text = "⌃"
            gravity = Gravity.CENTER
            textSize = 30f
            setTextColor(Color.WHITE)
            background = rounded(0xFF30303B.toInt(), 28)
            contentDescription = "Свернуть или развернуть панель"
        }
        box.addView(toggle, LinearLayout.LayoutParams(dp(46), dp(46)).apply { topMargin = dp(5) })
        toggle.setOnClickListener {
            collapsed = !collapsed
            counterView?.visibility = if (collapsed) View.GONE else View.VISIBLE
            controls?.visibility = if (collapsed) View.GONE else View.VISIBLE
            toggle.text = if (collapsed) "⌄" else "⌃"
            toggle.animate().cancel()
            toggle.alpha = 0.55f
            toggle.animate().alpha(1f).setDuration(180).start()
            panel?.let { try { wm.updateViewLayout(it, panelParams) } catch (_: Exception) {} }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels - dp(80)).coerceAtLeast(0)
            y = dp(120)
        }
        panel = box
        panelParams = params
        try { wm.addView(box, params) } catch (_: Exception) { stopSelf() }
        updateCounter()
    }

    private fun updateCounter() {
        // Left = completed taps; right = saved target points. They are independent.
        counterView?.text = "$taps:${points.size}"
        updateStatus()
    }

    private fun updateStatus() {
        statusView?.text = when {
            ClickAccessibilityService.instance == null -> "НЕТ СЛУЖ."
            points.isEmpty() -> "НЕТ ТОЧКИ"
            isRunning && paused -> "ПАУЗА"
            isRunning -> "РАБОТАЕТ"
            else -> "ГОТОВ"
        }
    }

    private fun syncPointFromMarker(view: View, pointIndex: Int, params: WindowManager.LayoutParams) {
        if (marker !== view || markerPointIndex != pointIndex || pointIndex !in points.indices) return
        val location = IntArray(2)
        view.getLocationOnScreen(location)
        screenOffsetX = location[0].toFloat() - params.x
        screenOffsetY = location[1].toFloat() - params.y
        screenOffsetKnown = true
        // GestureDescription expects screen coordinates. getLocationOnScreen gives the
        // actual on-screen center, including any Android window/system-bar offset.
        points[pointIndex] = (location[0] + params.width / 2f) to (location[1] + params.height / 2f)
        updateCounter()
    }

    private fun setMarkerTouchable(touchable: Boolean) {
        val view = marker ?: return
        val params = markerParams ?: return
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        // Android 12+ can block touches passing through opaque untrusted overlays.
        // Keep the marker translucent while click-through is enabled.
        params.alpha = if (touchable) 1f else 0.6f
        try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
    }

    private fun moveMarkerToPoint(pointIndex: Int) {
        val view = marker ?: return
        val params = markerParams ?: return
        if (pointIndex !in points.indices) return
        markerPointIndex = pointIndex
        if (screenOffsetKnown) {
            params.x = (points[pointIndex].first - screenOffsetX - params.width / 2f).toInt().coerceAtLeast(0)
            params.y = (points[pointIndex].second - screenOffsetY - params.height / 2f).toInt().coerceAtLeast(0)
        } else {
            params.x = (points[pointIndex].first - params.width / 2f).toInt().coerceAtLeast(0)
            params.y = (points[pointIndex].second - params.height / 2f).toInt().coerceAtLeast(0)
        }
        try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
        view.post { syncPointFromMarker(view, pointIndex, params) }
    }

    private fun removeLastPoint() {
        if (points.isEmpty()) {
            Toast.makeText(this, "Нет точек для удаления", Toast.LENGTH_SHORT).show()
            return
        }
        val removedIndex = points.lastIndex
        points.removeAt(removedIndex)
        if (points.isEmpty()) {
            if (isRunning) {
                paused = false
                setRunning(false)
            }
            marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            marker = null
            markerParams = null
            markerPointIndex = null
            screenOffsetKnown = false
            index = 0
            updateCounter()
            Toast.makeText(this, "Все точки удалены", Toast.LENGTH_SHORT).show()
            return
        }
        index %= points.size
        // Keep the crosshair on the last remaining point; it disappears only after
        // the final point is removed, and the right counter decreases independently.
        if (markerPointIndex == removedIndex || markerPointIndex == null || markerPointIndex !in points.indices) {
            moveMarkerToPoint(points.lastIndex)
        }
        updateCounter()
        Toast.makeText(this, "Точка удалена", Toast.LENGTH_SHORT).show()
    }

    private fun showMarker() {
        // Selecting a new target while running must pause first. Otherwise dispatchGesture
        // can cancel the user's drag of the target marker.
        if (isRunning && !paused) {
            paused = true
            handler.removeCallbacks(loop)
            updateStatus()
            Toast.makeText(this, "Пауза: передвинь прицел и нажми Старт", Toast.LENGTH_SHORT).show()
        }
        marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        marker = null
        markerParams = null
        screenOffsetKnown = false

        val v = TargetMarkerView(this)
        val p = WindowManager.LayoutParams(
            dp(76), dp(76), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels / 2 - dp(38)).coerceAtLeast(0)
            y = (resources.displayMetrics.heightPixels / 2 - dp(38)).coerceAtLeast(0)
        }
        val pointIndex = points.size
        points.add((p.x + p.width / 2f) to (p.y + p.height / 2f))
        marker = v
        markerParams = p
        markerPointIndex = pointIndex
        updateCounter()

        var downX = 0f
        var downY = 0f
        var originX = 0
        var originY = 0
        v.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    originX = p.x
                    originY = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (originX + (event.rawX - downX).toInt()).coerceAtLeast(0)
                    p.y = (originY + (event.rawY - downY).toInt()).coerceAtLeast(0)
                    try { wm.updateViewLayout(view, p) } catch (_: Exception) {}
                    if (screenOffsetKnown && pointIndex in points.indices) {
                        points[pointIndex] = (p.x + screenOffsetX + p.width / 2f) to
                            (p.y + screenOffsetY + p.height / 2f)
                        updateCounter()
                    } else {
                        view.post { syncPointFromMarker(view, pointIndex, p) }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (screenOffsetKnown && pointIndex in points.indices) {
                        points[pointIndex] = (p.x + screenOffsetX + p.width / 2f) to
                            (p.y + screenOffsetY + p.height / 2f)
                        updateCounter()
                    } else {
                        syncPointFromMarker(view, pointIndex, p)
                    }
                    setMarkerTouchable(!isRunning || paused)
                    Toast.makeText(this, "Точка сохранена: ${points.size}", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> true
            }
        }
        try {
            wm.addView(v, p)
            // Read the actual screen position only after WindowManager attaches the marker.
            v.post { syncPointFromMarker(v, pointIndex, p) }
            setMarkerTouchable(!isRunning || paused)
        } catch (_: Exception) {
            if (pointIndex in points.indices) points.removeAt(pointIndex)
            marker = null
            markerParams = null
            markerPointIndex = null
            updateCounter()
            Toast.makeText(this, "Не удалось показать прицел", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dragListener(): View.OnTouchListener {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        return View.OnTouchListener { _, e ->
            val p = panelParams ?: return@OnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y
                    userInteracting = true
                    handler.removeCallbacks(loop)
                    handler.removeCallbacks(interactionReset)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (ox + (e.rawX - sx).toInt()).coerceAtLeast(0)
                    p.y = (oy + (e.rawY - sy).toInt()).coerceAtLeast(0)
                    try { panel?.let { wm.updateViewLayout(it, p) } } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(interactionReset)
                    handler.postDelayed(interactionReset, 180L)
                    true
                }
                else -> true
            }
        }
    }

    override fun onDestroy() {
        setRunning(false)
        handler.removeCallbacksAndMessages(null)
        marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        marker = null; markerParams = null; markerPointIndex = null; panel = null
        if (serviceInstance === this) serviceInstance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        @Volatile private var runningState = false
        @Volatile private var serviceInstance: OverlayService? = null
        val isRunning: Boolean get() = runningState
        fun setRunning(value: Boolean) { runningState = value }
        fun refreshAccessibilityStatus() {
            serviceInstance?.let { overlay ->
                overlay.handler.post { overlay.updateStatus() }
            }
        }
    }

    private fun setRunning(value: Boolean) {
        OverlayService.setRunning(value)
        handler.removeCallbacks(loop)
        runToken++
        // A previous gesture callback can be invalidated by Stop or Pause/Resume. Reset
        // the local in-flight flag so the next run cannot get stuck waiting forever.
        gestureInFlight = false
        if (!value) {
            setMarkerTouchable(true)
        } else if (!paused) {
            // While tapping, let the target overlay pass touches through to the app below it.
            setMarkerTouchable(false)
            if (!userInteracting) handler.post(loop)
        }
        updateStatus()
    }
}

private class TargetMarkerView(context: android.content.Context) : View(context) {
    private val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 255, 40); style = Paint.Style.STROKE; strokeWidth = 4f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x6630FF50; style = Paint.Style.FILL }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 255, 40); strokeWidth = 3f }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f; val r = width.coerceAtMost(height) * 0.39f
        canvas.drawCircle(cx, cy, r, fill)
        canvas.drawCircle(cx, cy, r, outer)
        canvas.drawLine(cx - r, cy, cx + r, cy, cross)
        canvas.drawLine(cx, cy - r, cx, cy + r, cross)
    }
}
