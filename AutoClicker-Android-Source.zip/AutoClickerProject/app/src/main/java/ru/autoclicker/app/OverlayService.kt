package ru.autoclicker.app

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.RadioGroup
import android.widget.RadioButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var marker: View? = null
    private var markerParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var counterView: TextView? = null
    private var statusView: TextView? = null
    private var controls: LinearLayout? = null
    private var settingsPopup: View? = null
    private var settingsPopupParams: WindowManager.LayoutParams? = null
    private var settingsWasRunning = false
    private var collapsed = false
    private val handler = Handler(Looper.getMainLooper())
    private var index = 0
    private var taps = 0L
    private var paused = false
    private var gestureInFlight = false
    private var consecutiveFailures = 0
    private var runToken = 0L
    private val points = mutableListOf<Pair<Float, Float>>()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val interval get() = prefs.getLong("interval", 500L).coerceIn(1L, 86_400_000L)
    private val limit get() = prefs.getLong("count", 0L).coerceAtLeast(0)
    private val clickMode get() = prefs.getString("clickMode", "tap") ?: "tap"

    private val loop = object : Runnable {
        override fun run() {
            if (!isRunning || paused) return
            // Do not dispatch a new accessibility gesture while the user is touching
            // the floating panel. dispatchGesture cancels touches already in progress,
            // which previously made Pause/Stop appear to require two taps.
            if (userInteracting) return
            val service = ClickAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this@OverlayService, "Сначала включи службу специальных возможностей", Toast.LENGTH_LONG).show()
                setRunning(false)
                return
            }
            if (points.isEmpty()) {
                Toast.makeText(this@OverlayService, "Добавь хотя бы одну точку кнопкой ⊕", Toast.LENGTH_SHORT).show()
                setRunning(false)
                return
            }
            if (clickMode == "tap" && limit > 0 && taps >= limit) {
                setRunning(false)
                Toast.makeText(this@OverlayService, "Лимит нажатий достигнут", Toast.LENGTH_SHORT).show()
                return
            }
            if (gestureInFlight) {
                handler.postDelayed(this, 20L)
                return
            }
            val p = points[index % points.size]
            val token = runToken
            gestureInFlight = true
            if (clickMode == "hold") {
                val acceptedHold = service.hold(p.first, p.second) { completed ->
                    if (token != runToken) return@hold
                    gestureInFlight = false
                    if (!completed) {
                        consecutiveFailures++
                        if (consecutiveFailures >= 3) {
                            setRunning(false)
                            Toast.makeText(this@OverlayService,
                                "Android прервал удержание. Проверь службу специальных возможностей.",
                                Toast.LENGTH_LONG).show()
                            return@hold
                        }
                    } else {
                        consecutiveFailures = 0
                    }
                    if (isRunning && !paused && !userInteracting) handler.postDelayed(this, interval)
                }
                if (!acceptedHold) {
                    // hold() reports a failed dispatch through its callback as well.
                }
                return
            }
            val accepted = service.tap(p.first, p.second) { completed ->
                if (token != runToken) return@tap
                gestureInFlight = false
                if (completed) {
                    taps++
                    index++
                    consecutiveFailures = 0
                    updateCounter()
                } else {
                    consecutiveFailures++
                    if (consecutiveFailures >= 3) {
                        setRunning(false)
                        Toast.makeText(this@OverlayService,
                            "Android отклоняет нажатия. Кликер остановлен; проверь службу специальных возможностей.",
                            Toast.LENGTH_LONG).show()
                        return@tap
                    }
                }
                if (isRunning && !paused && !userInteracting) handler.postDelayed(this, interval)
            }
            if (!accepted) {
                // dispatchGesture can reject a request without delivering a callback.
                // tap() invokes the callback on rejection; don't leave the loop stuck.
            }
        }
    }

    // While any panel button is pressed, suspend scheduling of new dispatchGesture calls.
    // The delayed reset lets Android deliver ACTION_UP/onClick before automatic tapping resumes.
    private var userInteracting = false
    private var markerPointIndex: Int? = null
    private var screenOffsetX = 0f
    private var screenOffsetY = 0f
    private var screenOffsetKnown = false
    private val interactionReset = Runnable {
        userInteracting = false
        resumeLoopAfterPanelInteraction()
    }
    // A safeguard in case Android cancels an overlay touch before ACTION_UP is delivered.
    private val interactionWatchdog = Runnable {
        userInteracting = false
        resumeLoopAfterPanelInteraction()
    }

    /** Always restart scheduling after panel touches; collapsing must never toggle run state. */
    private fun resumeLoopAfterPanelInteraction() {
        // Keep automation suspended while the settings window is being edited.
        if (settingsPopup != null) {
            userInteracting = true
            return
        }
        if (isRunning && !paused) {
            handler.removeCallbacks(loop)
            // If Android cancelled a gesture because the overlay was touched, the loop
            // waits on gestureInFlight until its callback clears it. Posting is safe:
            // loop retries briefly while an existing callback is still pending.
            handler.post(loop)
        }
    }

    private fun flashButton(button: TextView, radius: Int = 9) {
        button.animate().cancel()
        button.background = rounded(0xFF85858F.toInt(), radius)
        button.scaleX = 0.96f
        button.scaleY = 0.96f
        button.postDelayed({
            if (button.isAttachedToWindow) {
                button.background = rounded(0xFF55555F.toInt(), radius)
                button.animate().scaleX(1f).scaleY(1f).setDuration(100L).start()
            }
        }, 170L)
    }

    override fun onCreate() {
        super.onCreate()
        serviceInstance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
        showPanel()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 14): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun iconButton(icon: String, description: String, color: Int, action: () -> Unit): TextView {
        val button = TextView(this).apply {
            text = icon
            contentDescription = description
            gravity = Gravity.CENTER
            textSize = 16f
            typeface = Typeface.DEFAULT
            setTextColor(Color.WHITE)
            background = rounded(0xFF55555F.toInt(), 9)
            isClickable = true
            isFocusable = false
            setPadding(0, 0, 0, 0)
            elevation = dp(2).toFloat()
        }
        val lp = LinearLayout.LayoutParams(dp(32), dp(28)).apply { topMargin = 0; bottomMargin = 0 }
        button.setOnClickListener {
            flashButton(button, 9)
            action()
        }
        button.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    button.background = rounded(0xFF85858F.toInt(), 9)
                    userInteracting = true
                    handler.removeCallbacks(loop)
                    handler.removeCallbacks(interactionReset)
                    handler.removeCallbacks(interactionWatchdog)
                    handler.postDelayed(interactionWatchdog, 1500L)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(interactionWatchdog)
                    handler.removeCallbacks(interactionReset)
                    handler.postDelayed(interactionReset, 180L)
                    button.postDelayed({
                        if (button.isAttachedToWindow) button.background = rounded(0xFF55555F.toInt(), 9)
                    }, 170L)
                }
            }
            // Return false so TextView still handles the touch and fires its click listener.
            false
        }
        button.tag = lp
        return button
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = rounded(0xF21B1B25.toInt(), 15)
            clipToPadding = false
        }
        val header = TextView(this).apply {
            text = "Auto\nClicker"
            gravity = Gravity.CENTER
            textSize = 10f
            setTextColor(Color.WHITE)
            setPadding(dp(1), dp(2), dp(1), dp(2))
            contentDescription = "Перетащить панель"
        }
        box.addView(header, LinearLayout.LayoutParams(dp(36), dp(32)))
        header.setOnTouchListener(dragListener())

        counterView = TextView(this).apply {
            text = "0:0"
            gravity = Gravity.CENTER
            textSize = 9f
            setTextColor(0xFFD8D2FF.toInt())
            contentDescription = "Счётчик нажатий и точек"
        }
        box.addView(counterView, LinearLayout.LayoutParams(dp(38), dp(17)))

        statusView = TextView(this).apply {
            text = "НЕТ СЛУЖ."
            gravity = Gravity.CENTER
            textSize = 7f
            setTextColor(0xFFBDBDC8.toInt())
            contentDescription = "Состояние кликера"
            setPadding(0, 0, 0, 0)
        }
        box.addView(statusView, LinearLayout.LayoutParams(dp(42), dp(12)))

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        controls?.addView(iconButton("⚙", "Настройки режима и интервала", 0xFF55555F.toInt()) {
            showSettingsPopup()
        }, LinearLayout.LayoutParams(dp(32), dp(28)).apply { topMargin = dp(1); bottomMargin = dp(1) })
        controls?.addView(iconButton("▶", "Старт", 0xFF55555F.toInt()) {
            if (ClickAccessibilityService.instance == null) {
                Toast.makeText(this, "Сначала включи службу специальных возможностей", Toast.LENGTH_LONG).show()
            } else if (points.isEmpty()) {
                Toast.makeText(this, "Сначала добавь точку кнопкой ⊕", Toast.LENGTH_SHORT).show()
            } else if (!isRunning) {
                paused = false
                consecutiveFailures = 0
                setRunning(true)
            } else if (paused) {
                paused = false
                setRunning(true)
            } else {
                Toast.makeText(this, "Кликер уже работает", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(dp(32), dp(28)).apply { topMargin = dp(1); bottomMargin = dp(1) })
        controls?.addView(iconButton("Ⅱ", "Пауза", 0xFF55555F.toInt()) {
            if (isRunning && !paused) {
                paused = true
                handler.removeCallbacks(loop)
                // Invalidate any pending tap/hold callback before releasing a Hold gesture.
                runToken++
                gestureInFlight = false
                ClickAccessibilityService.instance?.releaseHold()
                setMarkerTouchable(true)
                updateStatus()
                Toast.makeText(this, "Пауза", Toast.LENGTH_SHORT).show()
            } else if (paused) {
                Toast.makeText(this, "Уже на паузе", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(dp(32), dp(28)).apply { topMargin = dp(1); bottomMargin = dp(1) })
        controls?.addView(iconButton("■", "Стоп", 0xFF55555F.toInt()) {
            paused = false
            // Do not remove all Handler messages: the pending touch-release guard must
            // still clear userInteracting after this Stop click.
            handler.removeCallbacks(loop)
            setRunning(false)
            gestureInFlight = false
            consecutiveFailures = 0
            taps = 0
            index = 0
            updateCounter()
            Toast.makeText(this, "Остановлено", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(dp(32), dp(28)).apply { topMargin = dp(1); bottomMargin = dp(1) })
        controls?.addView(iconButton("⊕", "Добавить точку", 0xFF55555F.toInt()) { showMarker() },
            LinearLayout.LayoutParams(dp(32), dp(28)).apply { topMargin = dp(1); bottomMargin = dp(1) })
        controls?.addView(iconButton("−", "Удалить последнюю точку", 0xFF55555F.toInt()) {
            removeLastPoint()
        }, LinearLayout.LayoutParams(dp(32), dp(28)).apply { topMargin = dp(1); bottomMargin = dp(1) })
        controls?.addView(iconButton("×", "Закрыть панель", 0xFF55555F.toInt()) {
            setRunning(false)
            paused = false
            stopSelf()
        }, LinearLayout.LayoutParams(dp(32), dp(28)).apply { topMargin = dp(1); bottomMargin = dp(1) })
        box.addView(controls)

        val toggle = TextView(this).apply {
            text = "⌃"
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            background = rounded(0xFF55555F.toInt(), 18)
            contentDescription = "Свернуть или развернуть панель"
        }
        box.addView(toggle, LinearLayout.LayoutParams(dp(32), dp(27)).apply { topMargin = dp(2) })
        toggle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    toggle.background = rounded(0xFF85858F.toInt(), 18)
                    userInteracting = true
                    handler.removeCallbacks(loop)
                    handler.removeCallbacks(interactionReset)
                    handler.removeCallbacks(interactionWatchdog)
                    handler.postDelayed(interactionWatchdog, 1500L)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(interactionWatchdog)
                    handler.removeCallbacks(interactionReset)
                    handler.postDelayed(interactionReset, 180L)
                    toggle.postDelayed({
                        if (toggle.isAttachedToWindow) toggle.background = rounded(0xFF55555F.toInt(), 18)
                    }, 170L)
                }
            }
            false
        }
        toggle.setOnClickListener {
            collapsed = !collapsed
            counterView?.visibility = if (collapsed) View.GONE else View.VISIBLE
            controls?.visibility = if (collapsed) View.GONE else View.VISIBLE
            toggle.text = if (collapsed) "⌄" else "⌃"
            flashButton(toggle, 18)
            panel?.let { try { wm.updateViewLayout(it, panelParams) } catch (_: Exception) {} }
            // Android may cancel the in-flight accessibility gesture when the overlay is
            // touched. Independently of the touch listener's timing, resume scheduling
            // after the collapsed/expanded layout has settled without changing run state.
            handler.removeCallbacks(interactionWatchdog)
            handler.removeCallbacks(interactionReset)
            handler.postDelayed(interactionReset, 220L)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels - dp(58)).coerceAtLeast(0)
            y = dp(120)
        }
        panel = box
        panelParams = params
        try { wm.addView(box, params) } catch (_: Exception) { stopSelf() }
        updateCounter()
    }

    private fun dismissSettingsPopup(popup: View) {
        try { wm.removeView(popup) } catch (_: Exception) {}
        if (settingsPopup === popup) settingsPopup = null
        settingsPopupParams = null
        val resumeAfter = settingsWasRunning
        settingsWasRunning = false
        handler.removeCallbacks(interactionReset)
        handler.removeCallbacks(interactionWatchdog)
        userInteracting = false
        // Let the close/save touch finish before sending the next accessibility gesture.
        if (resumeAfter && isRunning && !paused) {
            handler.postDelayed({
                if (settingsPopup == null && isRunning && !paused) {
                    userInteracting = false
                    resumeLoopAfterPanelInteraction()
                }
            }, 180L)
        }
    }

    private fun showSettingsPopup() {
        settingsPopup?.let { old ->
            try { wm.removeView(old) } catch (_: Exception) {}
            settingsPopup = null
        }
        settingsWasRunning = isRunning && !paused
        userInteracting = true
        handler.removeCallbacks(loop)
        // If an uninterrupted Hold is active, release it while the user edits settings;
        // it will be restarted at the saved target once the popup closes.
        if (settingsWasRunning && clickMode == "hold" && gestureInFlight) {
            runToken++
            gestureInFlight = false
            ClickAccessibilityService.instance?.releaseHold()
        }
        val unitNames = arrayOf("мс", "сек", "мин")
        val factors = longArrayOf(1L, 1_000L, 60_000L)
        var activeUnit = prefs.getString("intervalUnit", "мс") ?: "мс"
        if (activeUnit !in unitNames) activeUnit = "мс"
        fun factor(unit: String = activeUnit) = factors[unitNames.indexOf(unit).coerceAtLeast(0)]
        fun format(ms: Long, unit: String = activeUnit): String {
            val f = factor(unit).toDouble()
            val digits = when (unit) { "мс" -> 0; "сек" -> 3; else -> 7 }
            return String.format(java.util.Locale.US, "%1$.${digits}f", ms.toDouble() / f)
                .let { if (it.contains('.')) it.trimEnd('0').trimEnd('.') else it }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(0xFF25252F.toInt(), 16)
            elevation = dp(12).toFloat()
        }
        val title = TextView(this).apply {
            text = "Настройки"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        box.addView(title, LinearLayout.LayoutParams(-1, dp(32)))
        val modeLabel = TextView(this).apply { text = "Режим действия"; setTextColor(Color.WHITE); textSize = 14f }
        box.addView(modeLabel, LinearLayout.LayoutParams(-1, dp(28)))
        val modes = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val tap = RadioButton(this).apply {
            text = "Tap"; setTextColor(Color.WHITE); id = View.generateViewId()
            buttonTintList = android.content.res.ColorStateList.valueOf(0xFFAAAAB2.toInt())
            background = rounded(0xFF55555F.toInt(), 8)
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> view.background = rounded(0xFF85858F.toInt(), 8)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.postDelayed({
                        if (view.isAttachedToWindow) view.background = rounded(0xFF55555F.toInt(), 8)
                    }, 170L)
                }
                false
            }
        }
        val hold = RadioButton(this).apply {
            text = "Hold"; setTextColor(Color.WHITE); id = View.generateViewId()
            buttonTintList = android.content.res.ColorStateList.valueOf(0xFFAAAAB2.toInt())
            background = rounded(0xFF55555F.toInt(), 8)
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> view.background = rounded(0xFF85858F.toInt(), 8)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.postDelayed({
                        if (view.isAttachedToWindow) view.background = rounded(0xFF55555F.toInt(), 8)
                    }, 170L)
                }
                false
            }
        }
        modes.addView(tap, RadioGroup.LayoutParams(0, dp(42), 1f))
        modes.addView(hold, RadioGroup.LayoutParams(0, dp(42), 1f))
        if (clickMode == "hold") hold.isChecked = true else tap.isChecked = true
        box.addView(modes)
        val intervalLabel = TextView(this).apply { text = "Интервал между действиями"; setTextColor(Color.WHITE); textSize = 14f }
        box.addView(intervalLabel, LinearLayout.LayoutParams(-1, dp(28)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val amount = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true); setText(format(interval)); setTextColor(Color.WHITE); textSize = 15f
            setPadding(dp(8), dp(4), dp(8), dp(4)); background = rounded(0xFF3A3A45.toInt(), 8)
        }
        val units = Spinner(this).apply {
            adapter = ArrayAdapter(this@OverlayService, android.R.layout.simple_spinner_dropdown_item, unitNames)
            setSelection(unitNames.indexOf(activeUnit).coerceAtLeast(0))
            background = rounded(0xFF55555F.toInt(), 8)
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> view.background = rounded(0xFF85858F.toInt(), 8)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.postDelayed({
                        if (view.isAttachedToWindow) view.background = rounded(0xFF55555F.toInt(), 8)
                    }, 170L)
                }
                false
            }
        }
        fun currentMs(): Long {
            val n = amount.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: return interval
            return (n * factor().toDouble()).toLong().coerceIn(1L, 86_400_000L)
        }
        fun adjust(dir: Int) {
            val step = factor()
            val next = (currentMs() + dir * step).coerceIn(1L, 86_400_000L)
            amount.setText(format(next)); amount.setSelection(amount.text.length)
        }
        fun smallButton(text: String, action: () -> Unit) = TextView(this).apply {
            this.text = text; gravity = Gravity.CENTER; textSize = 20f; setTextColor(Color.WHITE)
            background = rounded(0xFF55555F.toInt(), 8); isClickable = true; isFocusable = true
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> view.background = rounded(0xFF85858F.toInt(), 8)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.postDelayed({
                        if (view.isAttachedToWindow) view.background = rounded(0xFF55555F.toInt(), 8)
                    }, 170L)
                }
                false
            }
            setOnClickListener { flashButton(this, 8); action() }
        }
        fun adjustmentButton(text: String, direction: Int): TextView {
            val button = smallButton(text) { adjust(direction) }
            var repeating = false
            var fingerDown = false
            var repeatCount = 0
            val repeater = object : Runnable {
                override fun run() {
                    repeatCount++
                    val multiplier = when {
                        repeatCount >= 24 -> 25
                        repeatCount >= 15 -> 10
                        repeatCount >= 7 -> 5
                        else -> 1
                    }
                    adjust(direction * multiplier)
                    if (fingerDown) handler.postDelayed(this, if (repeatCount < 7) 150L else 55L)
                }
            }
            button.setOnLongClickListener {
                repeating = true
                repeatCount = 0
                adjust(direction)
                handler.postDelayed(repeater, 250L)
                true
            }
            button.setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        view.background = rounded(0xFF85858F.toInt(), 8)
                        fingerDown = true
                        repeating = false
                        repeatCount = 0
                        handler.removeCallbacks(repeater)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        fingerDown = false
                        handler.removeCallbacks(repeater)
                        view.postDelayed({ if (view.isAttachedToWindow) view.background = rounded(0xFF55555F.toInt(), 8) }, 170L)
                    }
                }
                false
            }
            // ACTION_UP triggers this only for a short press. Long-press is consumed above.
            button.setOnClickListener {
                if (!repeating) adjust(direction)
                flashButton(button, 8)
            }
            return button
        }
        val minus = adjustmentButton("<", -1)
        val plus = adjustmentButton(">", 1)
        row.addView(minus, LinearLayout.LayoutParams(dp(36), dp(40)))
        row.addView(amount, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5); rightMargin = dp(5) })
        row.addView(plus, LinearLayout.LayoutParams(dp(36), dp(40)))
        row.addView(units, LinearLayout.LayoutParams(dp(64), dp(42)).apply { leftMargin = dp(5) })
        box.addView(row, LinearLayout.LayoutParams(-1, dp(46)))
        units.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val next = unitNames[position.coerceIn(0, unitNames.lastIndex)]
                if (next != activeUnit) { val ms = currentMs(); activeUnit = next; amount.setText(format(ms)); amount.setSelection(amount.text.length) }
            }
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val save = smallButton("Сохранить настройки") {
            val ms = currentMs()
            prefs.edit().putLong("interval", ms).putString("intervalUnit", activeUnit).apply()
            setClickMode(if (hold.isChecked) "hold" else "tap")
            dismissSettingsPopup(box)
            Toast.makeText(this@OverlayService, "Настройки сохранены", Toast.LENGTH_SHORT).show()
        }.apply { textSize = 12f }
        val close = smallButton("Закрыть") {
            dismissSettingsPopup(box)
        }.apply { textSize = 14f }
        actions.addView(save, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(5) })
        actions.addView(close, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5) })
        box.addView(actions, LinearLayout.LayoutParams(-1, dp(44)))
        val popupParams = WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER; softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE }
        try {
            wm.addView(box, popupParams)
            settingsPopup = box
            settingsPopupParams = popupParams
        } catch (_: Exception) {
            settingsPopup = null
            settingsPopupParams = null
            val resumeAfter = settingsWasRunning
            settingsWasRunning = false
            userInteracting = false
            if (resumeAfter && isRunning && !paused) handler.postDelayed({ resumeLoopAfterPanelInteraction() }, 180L)
            Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setClickMode(mode: String) {
        if (mode != "tap" && mode != "hold") return
        if (clickMode == mode) {
            Toast.makeText(this, if (mode == "hold") "Режим Hold уже выбран" else "Режим Tap уже выбран", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.edit().putString("clickMode", mode).apply()
        if (mode == "tap" && gestureInFlight) {
            // Stop the continuous hold immediately when switching back to Tap.
            runToken++
            gestureInFlight = false
            ClickAccessibilityService.instance?.releaseHold()
            if (isRunning && !paused && !userInteracting) handler.postDelayed(loop, 200L)
        }
        updateStatus()
        Toast.makeText(this, if (mode == "hold") "Режим Hold: удерживать до Паузы или Стоп" else "Режим Tap: короткие нажатия", Toast.LENGTH_SHORT).show()
    }

    private fun updateCounter() {
        // Left = completed taps; right = saved target points. They are independent.
        counterView?.text = "$taps:${points.size}"
        updateStatus()
    }

    private fun updateStatus() {
        statusView?.text = when {
            ClickAccessibilityService.instance == null -> "НЕТ СЛУЖ."
            points.isEmpty() -> "НЕТ ТОЧКИ"
            isRunning && paused -> "ПАУЗА"
            isRunning && clickMode == "hold" -> "HOLD"
            isRunning -> "TAP"
            else -> "ГОТОВ"
        }
    }

    private fun syncPointFromMarker(view: View, pointIndex: Int, params: WindowManager.LayoutParams) {
        if (marker !== view || markerPointIndex != pointIndex || pointIndex !in points.indices) return
        val location = IntArray(2)
        view.getLocationOnScreen(location)
        screenOffsetX = location[0].toFloat() - params.x
        screenOffsetY = location[1].toFloat() - params.y
        screenOffsetKnown = true
        // GestureDescription expects screen coordinates. getLocationOnScreen gives the
        // actual on-screen center, including any Android window/system-bar offset.
        points[pointIndex] = (location[0] + params.width / 2f) to (location[1] + params.height / 2f)
        updateCounter()
    }

    private fun setMarkerTouchable(touchable: Boolean) {
        val view = marker ?: return
        val params = markerParams ?: return
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        // Android 12+ can block touches passing through opaque untrusted overlays.
        // Keep the marker translucent while click-through is enabled.
        params.alpha = if (touchable) 1f else 0.6f
        try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
    }

    private fun moveMarkerToPoint(pointIndex: Int) {
        val view = marker ?: return
        val params = markerParams ?: return
        if (pointIndex !in points.indices) return
        markerPointIndex = pointIndex
        if (screenOffsetKnown) {
            params.x = (points[pointIndex].first - screenOffsetX - params.width / 2f).toInt().coerceAtLeast(0)
            params.y = (points[pointIndex].second - screenOffsetY - params.height / 2f).toInt().coerceAtLeast(0)
        } else {
            params.x = (points[pointIndex].first - params.width / 2f).toInt().coerceAtLeast(0)
            params.y = (points[pointIndex].second - params.height / 2f).toInt().coerceAtLeast(0)
        }
        try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
        view.post { syncPointFromMarker(view, pointIndex, params) }
    }

    private fun removeLastPoint() {
        if (clickMode == "hold" && isRunning && !paused) {
            // Pause before editing points so a held pointer cannot remain on a removed target.
            paused = true
            handler.removeCallbacks(loop)
            runToken++
            gestureInFlight = false
            ClickAccessibilityService.instance?.releaseHold()
            setMarkerTouchable(true)
            updateStatus()
        }
        if (points.isEmpty()) {
            Toast.makeText(this, "Нет точек для удаления", Toast.LENGTH_SHORT).show()
            return
        }
        val removedIndex = points.lastIndex
        points.removeAt(removedIndex)
        if (points.isEmpty()) {
            if (isRunning) {
                paused = false
                setRunning(false)
            }
            marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            marker = null
            markerParams = null
            markerPointIndex = null
            screenOffsetKnown = false
            index = 0
            updateCounter()
            Toast.makeText(this, "Все точки удалены", Toast.LENGTH_SHORT).show()
            return
        }
        index %= points.size
        // Keep the crosshair on the last remaining point; it disappears only after
        // the final point is removed, and the right counter decreases independently.
        if (markerPointIndex == removedIndex || markerPointIndex == null || markerPointIndex !in points.indices) {
            moveMarkerToPoint(points.lastIndex)
        }
        updateCounter()
        Toast.makeText(this, "Точка удалена", Toast.LENGTH_SHORT).show()
    }

    private fun showMarker() {
        // Selecting a new target while running must pause first. Otherwise dispatchGesture
        // can cancel the user's drag of the target marker.
        if (isRunning && !paused) {
            paused = true
            handler.removeCallbacks(loop)
            runToken++
            gestureInFlight = false
            ClickAccessibilityService.instance?.releaseHold()
            setMarkerTouchable(true)
            updateStatus()
            Toast.makeText(this, "Пауза: передвинь прицел и нажми Старт", Toast.LENGTH_SHORT).show()
        }
        marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        marker = null
        markerParams = null
        screenOffsetKnown = false

        val v = TargetMarkerView(this)
        val p = WindowManager.LayoutParams(
            dp(76), dp(76), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels / 2 - dp(38)).coerceAtLeast(0)
            y = (resources.displayMetrics.heightPixels / 2 - dp(38)).coerceAtLeast(0)
        }
        val pointIndex = points.size
        points.add((p.x + p.width / 2f) to (p.y + p.height / 2f))
        marker = v
        markerParams = p
        markerPointIndex = pointIndex
        updateCounter()

        var downX = 0f
        var downY = 0f
        var originX = 0
        var originY = 0
        v.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    originX = p.x
                    originY = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (originX + (event.rawX - downX).toInt()).coerceAtLeast(0)
                    p.y = (originY + (event.rawY - downY).toInt()).coerceAtLeast(0)
                    try { wm.updateViewLayout(view, p) } catch (_: Exception) {}
                    if (screenOffsetKnown && pointIndex in points.indices) {
                        points[pointIndex] = (p.x + screenOffsetX + p.width / 2f) to
                            (p.y + screenOffsetY + p.height / 2f)
                        updateCounter()
                    } else {
                        view.post { syncPointFromMarker(view, pointIndex, p) }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (screenOffsetKnown && pointIndex in points.indices) {
                        points[pointIndex] = (p.x + screenOffsetX + p.width / 2f) to
                            (p.y + screenOffsetY + p.height / 2f)
                        updateCounter()
                    } else {
                        syncPointFromMarker(view, pointIndex, p)
                    }
                    setMarkerTouchable(!isRunning || paused)
                    Toast.makeText(this, "Точка сохранена: ${points.size}", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> true
            }
        }
        try {
            wm.addView(v, p)
            // Read the actual screen position only after WindowManager attaches the marker.
            v.post { syncPointFromMarker(v, pointIndex, p) }
            setMarkerTouchable(!isRunning || paused)
        } catch (_: Exception) {
            if (pointIndex in points.indices) points.removeAt(pointIndex)
            marker = null
            markerParams = null
            markerPointIndex = null
            updateCounter()
            Toast.makeText(this, "Не удалось показать прицел", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dragListener(): View.OnTouchListener {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        return View.OnTouchListener { _, e ->
            val p = panelParams ?: return@OnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y
                    userInteracting = true
                    handler.removeCallbacks(loop)
                    handler.removeCallbacks(interactionReset)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (ox + (e.rawX - sx).toInt()).coerceAtLeast(0)
                    p.y = (oy + (e.rawY - sy).toInt()).coerceAtLeast(0)
                    try { panel?.let { wm.updateViewLayout(it, p) } } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(interactionReset)
                    handler.postDelayed(interactionReset, 180L)
                    true
                }
                else -> true
            }
        }
    }

    override fun onDestroy() {
        setRunning(false)
        handler.removeCallbacksAndMessages(null)
        marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        settingsPopup?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        settingsPopup = null
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        marker = null; markerParams = null; markerPointIndex = null; panel = null
        if (serviceInstance === this) serviceInstance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        @Volatile private var runningState = false
        @Volatile private var serviceInstance: OverlayService? = null
        val isRunning: Boolean get() = runningState
        fun setRunning(value: Boolean) { runningState = value }
        fun refreshAccessibilityStatus() {
            serviceInstance?.let { overlay ->
                overlay.handler.post { overlay.updateStatus() }
            }
        }
        fun stopForAccessibilityInterrupt() {
            serviceInstance?.let { overlay ->
                overlay.handler.post {
                    overlay.paused = false
                    overlay.setRunning(false)
                    overlay.updateStatus()
                }
            } ?: setRunning(false)
        }
    }

    private fun setRunning(value: Boolean) {
        OverlayService.setRunning(value)
        handler.removeCallbacks(loop)
        runToken++
        // A previous gesture callback can be invalidated by Stop or Pause/Resume. Reset
        // the local in-flight flag so the next run cannot get stuck waiting forever.
        gestureInFlight = false
        if (!value) {
            ClickAccessibilityService.instance?.releaseHold()
            setMarkerTouchable(true)
        } else if (!paused) {
            // While tapping, let the target overlay pass touches through to the app below it.
            setMarkerTouchable(false)
            if (!userInteracting) handler.post(loop)
        }
        updateStatus()
    }
}

private class TargetMarkerView(context: android.content.Context) : View(context) {
    private val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 255, 40); style = Paint.Style.STROKE; strokeWidth = 4f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x6630FF50; style = Paint.Style.FILL }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 255, 40); strokeWidth = 3f }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f; val r = width.coerceAtMost(height) * 0.39f
        canvas.drawCircle(cx, cy, r, fill)
        canvas.drawCircle(cx, cy, r, outer)
        canvas.drawLine(cx - r, cy, cx + r, cy, cross)
        canvas.drawLine(cx, cy - r, cx, cy + r, cross)
    }
}
