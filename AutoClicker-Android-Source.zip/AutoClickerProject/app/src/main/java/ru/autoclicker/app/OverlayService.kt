package ru.autoclicker.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var marker: View? = null
    private var markerParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var index = 0
    private var taps = 0L
    private var paused = false
    private var points = mutableListOf<Pair<Float, Float>>()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val interval get() = prefs.getLong("interval", 500L).coerceIn(50, 60000)
    private val limit get() = prefs.getLong("count", 0L).coerceAtLeast(0)
    private val loop = object : Runnable {
        override fun run() {
            if (!isRunning || paused) return
            val service = ClickAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this@OverlayService, "Сначала включи службу специальных возможностей", Toast.LENGTH_LONG).show()
                setRunning(false); return
            }
            if (points.isEmpty()) {
                Toast.makeText(this@OverlayService, "Добавь хотя бы одну точку кнопкой «Точка»", Toast.LENGTH_SHORT).show()
                setRunning(false); return
            }
            if (limit > 0 && taps >= limit) { setRunning(false); return }
            val p = points[index % points.size]
            index++; taps++; updateCounter()
            service.tap(p.first, p.second) { if (isRunning && !paused) handler.postDelayed(this, interval) }
        }
    }

    override fun onCreate() {
        super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
        showPanel()
    }
    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(10, 8, 10, 8); setBackgroundColor(0xEE20202C.toInt())
        }
        val header = TextView(this).apply { text = "Auto Clicker  ⋮"; setTextColor(Color.WHITE); textSize = 14f; setPadding(8, 8, 8, 8) }
        box.addView(header)
        header.setOnTouchListener(dragListener { panelParams })
        val counter = TextView(this).apply { tag = "counter"; text = "Нажатий: 0"; setTextColor(0xFFD7D3FF.toInt()); setPadding(8, 4, 8, 8) }
        box.addView(counter)
        fun addButton(label: String, action: () -> Unit) {
            val b = Button(this).apply { text = label; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6650C8.toInt())) }
            box.addView(b, LinearLayout.LayoutParams(220, 44)); b.setOnClickListener { action() }
        }
        addButton("Старт") { if (points.isEmpty()) Toast.makeText(this, "Сначала добавь точку", Toast.LENGTH_SHORT).show() else { paused = false; setRunning(true) } }
        addButton("Пауза") { paused = true; handler.removeCallbacks(loop) }
        addButton("Стоп") { setRunning(false); taps = 0; updateCounter() }
        addButton("Точка +") { showMarker() }
        addButton("Закрыть панель") { setRunning(false); stopSelf() }
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 160 }
        panel = box; panelParams = params; wm.addView(box, params)
    }
    private fun updateCounter() { (panel as? LinearLayout)?.let { root -> for (i in 0 until root.childCount) { val v=root.getChildAt(i); if (v.tag == "counter") (v as TextView).text = "Нажатий: $taps · Точек: ${points.size}" } } }
    private fun showMarker() {
        if (marker != null) { try { wm.removeView(marker) } catch (_: Exception) {}; marker = null }
        val v = TextView(this).apply { text = "✚\nПеретащи\nи нажми"; gravity = Gravity.CENTER; textSize = 12f; setTextColor(Color.WHITE); setBackgroundColor(0xEE9A4DFF.toInt()); setPadding(8,8,8,8) }
        val p = WindowManager.LayoutParams(130, 100, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = resources.displayMetrics.widthPixels / 2 - 65; y = resources.displayMetrics.heightPixels / 2 - 50
        }
        marker = v; markerParams = p
        v.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { view.setTag(R.id.marker_start_x, event.rawX); view.setTag(R.id.marker_start_y, event.rawY); view.setTag(R.id.marker_orig_x, p.x); view.setTag(R.id.marker_orig_y, p.y); true }
                MotionEvent.ACTION_MOVE -> { p.x = (view.getTag(R.id.marker_orig_x) as Int) + (event.rawX - (view.getTag(R.id.marker_start_x) as Float)).toInt(); p.y = (view.getTag(R.id.marker_orig_y) as Int) + (event.rawY - (view.getTag(R.id.marker_start_y) as Float)).toInt(); wm.updateViewLayout(view, p); true }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.abs(event.rawX - (view.getTag(R.id.marker_start_x) as Float)) + kotlin.math.abs(event.rawY - (view.getTag(R.id.marker_start_y) as Float))
                    if (moved < 12f) {
                        val x = p.x + p.width / 2f; val y = p.y + p.height / 2f
                        points.add(x to y); updateCounter(); try { wm.removeView(view) } catch (_: Exception) {}; marker = null
                        Toast.makeText(this, "Точка добавлена: ${points.size}", Toast.LENGTH_SHORT).show()
                    }; true
                }
                else -> true
            }
        }
        wm.addView(v, p)
    }
    private fun dragListener(getParams: () -> WindowManager.LayoutParams?): View.OnTouchListener {
        var sx=0f; var sy=0f; var ox=0; var oy=0
        return View.OnTouchListener { view, e -> val p=getParams() ?: return@OnTouchListener false
            when(e.action) { MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; true }; MotionEvent.ACTION_MOVE -> { p.x=ox+(e.rawX-sx).toInt(); p.y=oy+(e.rawY-sy).toInt(); try { wm.updateViewLayout(panel,p) } catch (_:Exception) {}; true }; else -> true }
        }
    }
    override fun onDestroy() {
        setRunning(false); marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        marker = null; panel = null; super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object {
        @Volatile var isRunning = false
        fun setRunning(value: Boolean) { isRunning = value }
    }
    private fun setRunning(value: Boolean) {
        isRunning = value
        handler.removeCallbacks(loop)
        if (value && !paused) handler.post(loop)
    }
}
