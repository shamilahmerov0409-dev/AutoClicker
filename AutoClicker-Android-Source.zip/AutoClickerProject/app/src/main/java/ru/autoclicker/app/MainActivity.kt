package ru.autoclicker.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale
import kotlin.math.roundToLong

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val uiHandler = Handler(Looper.getMainLooper())
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val unitNames = arrayOf("мс", "сек", "мин")
    private val unitFactors = longArrayOf(1L, 1_000L, 60_000L)
    private val maxIntervalMs = 86_400_000L // 24 hours

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 16, 24)
        window.navigationBarColor = android.graphics.Color.rgb(16, 16, 24)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(android.graphics.Color.rgb(16, 16, 24))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(android.graphics.Color.WHITE)
        }

        root.addView(label("Auto Clicker", 28f))
        val subtitle = label("Автоматизация нажатий • локально на устройстве", 13f)
        subtitle.setTextColor(0xFFB7B7C8.toInt())
        root.addView(subtitle, margin(0, dp(6), 0, dp(22)))

        root.addView(label("Интервал между действиями"))
        val intervalRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val unitSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, unitNames).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(unitNames.indexOf(prefs.getString("intervalUnit", "мс")).coerceAtLeast(0))
        }
        var activeUnit = unitSpinner.selectedItem?.toString() ?: "мс"
        fun factor(unit: String = activeUnit) = unitFactors[unitNames.indexOf(unit).coerceIn(0, unitNames.lastIndex)]
        fun currentIntervalMs(edit: EditText): Long {
            val amount = edit.text.toString().trim().replace(',', '.').toDoubleOrNull()
            val fallback = prefs.getLong("interval", 500L).coerceIn(1L, maxIntervalMs)
            if (amount == null || amount.isNaN() || amount.isInfinite()) return fallback
            if (amount <= 0.0) return 1L
            return (amount * factor()).roundToLong().coerceIn(1L, maxIntervalMs)
        }
        fun formatAmount(milliseconds: Long, unit: String = activeUnit): String {
            val f = unitFactors[unitNames.indexOf(unit).coerceIn(0, unitNames.lastIndex)].toDouble()
            val value = milliseconds.toDouble() / f
            val digits = when (unit) { "мс" -> 0; "сек" -> 3; else -> 7 }
            val formatted = String.format(Locale.US, "%1$.${digits}f", value)
            return if (formatted.contains('.')) formatted.trimEnd('0').trimEnd('.').ifEmpty { "0" } else formatted
        }
        val interval = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(formatAmount(prefs.getLong("interval", 500L).coerceIn(1L, maxIntervalMs)))
            setTextColor(-1)
            setHintTextColor(0xFF777788.toInt())
            hint = "Например, 500"
            setPadding(dp(8), dp(10), dp(8), dp(10))
            setBackgroundColor(0xFF242432.toInt())
            textSize = 16f
        }
        fun adjustInterval(direction: Int, multiplier: Int) {
            val current = currentIntervalMs(interval)
            val step = factor() * multiplier.toLong()
            val updated = (current + direction.toLong() * step).coerceIn(1L, maxIntervalMs)
            interval.setText(formatAmount(updated))
            interval.setSelection(interval.text.length)
        }
        fun arrowButton(symbol: String, direction: Int): TextView {
            val arrow = TextView(this).apply {
                text = symbol
                textSize = 22f
                gravity = android.view.Gravity.CENTER
                setTextColor(-1)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFF6650C8.toInt())
                    cornerRadius = dp(9).toFloat()
                }
                isClickable = true
                isFocusable = true
            }
            var pressed = false
            var pressedAt = 0L
            val repeat = object : Runnable {
                override fun run() {
                    if (!pressed) return
                    val heldFor = SystemClock.uptimeMillis() - pressedAt
                    val multiplier = when {
                        heldFor < 900L -> 1
                        heldFor < 1_800L -> when (activeUnit) { "мс" -> 5; "сек" -> 2; else -> 1 }
                        else -> when (activeUnit) { "мс" -> 20; "сек" -> 5; else -> 2 }
                    }
                    adjustInterval(direction, multiplier)
                    val delay = if (heldFor < 900L) 180L else if (heldFor < 1_800L) 120L else 85L
                    uiHandler.postDelayed(this, delay)
                }
            }
            arrow.setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        pressed = true
                        pressedAt = SystemClock.uptimeMillis()
                        view.isPressed = true
                        adjustInterval(direction, 1)
                        uiHandler.removeCallbacks(repeat)
                        uiHandler.postDelayed(repeat, 400L)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        pressed = false
                        view.isPressed = false
                        uiHandler.removeCallbacks(repeat)
                        true
                    }
                    else -> true
                }
            }
            return arrow
        }
        val minus = arrowButton("<", -1)
        val plus = arrowButton(">", 1)
        intervalRow.addView(minus, LinearLayout.LayoutParams(dp(42), dp(46)))
        intervalRow.addView(interval, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
            leftMargin = dp(6); rightMargin = dp(6)
        })
        intervalRow.addView(plus, LinearLayout.LayoutParams(dp(42), dp(46)))
        intervalRow.addView(unitSpinner, LinearLayout.LayoutParams(dp(68), dp(48)).apply { leftMargin = dp(5) })
        root.addView(intervalRow, margin(0, dp(8), 0, dp(8)))

        unitSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val newUnit = unitNames[position.coerceIn(0, unitNames.lastIndex)]
                if (newUnit != activeUnit) {
                    val currentMs = currentIntervalMs(interval)
                    activeUnit = newUnit
                    interval.setText(formatAmount(currentMs, activeUnit))
                    interval.setSelection(interval.text.length)
                }
            }
        }

        root.addView(label("Количество нажатий в режиме Tap (0 = без ограничения)"), margin(0, dp(8), 0, 0))
        val count = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getLong("count", 0L).toString())
            setTextColor(-1)
            setHintTextColor(0xFF777788.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFF242432.toInt())
        }
        root.addView(count, margin(0, dp(8), 0, dp(16)))

        root.addView(label("Режим действия"), margin(0, 0, 0, dp(4)))
        val modeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val tapMode = RadioButton(this).apply { text = "Tap — нажать"; setTextColor(-1); id = View.generateViewId() }
        val holdMode = RadioButton(this).apply { text = "Hold — удерживать"; setTextColor(-1); id = View.generateViewId() }
        modeGroup.addView(tapMode, RadioGroup.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        modeGroup.addView(holdMode, RadioGroup.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (prefs.getString("clickMode", "tap") == "hold") holdMode.isChecked = true else tapMode.isChecked = true
        root.addView(modeGroup, margin(0, 0, 0, dp(14)))

        fun collectAndSave(showToast: Boolean) {
            val i = currentIntervalMs(interval)
            val c = count.text.toString().trim().toLongOrNull()?.coerceAtLeast(0L) ?: 0L
            val mode = if (holdMode.isChecked) "hold" else "tap"
            prefs.edit()
                .putLong("interval", i)
                .putLong("count", c)
                .putString("intervalUnit", activeUnit)
                .putString("clickMode", mode)
                .apply()
            if (showToast) Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show()
        }
        val save = button("Сохранить настройки")
        save.setOnClickListener { collectAndSave(true) }
        root.addView(save, margin(0, 0, 0, dp(10)))

        val permission = button("1. Включить службу специальных возможностей")
        permission.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(permission, margin(0, 0, 0, dp(10)))
        val overlayPermission = button("2. Разрешить отображение поверх приложений")
        overlayPermission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
        }
        root.addView(overlayPermission, margin(0, 0, 0, dp(10)))

        val show = button("Показать плавающую панель")
        show.setOnClickListener {
            collectAndSave(false)
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Разреши отображение поверх приложений, затем вернись сюда", Toast.LENGTH_LONG).show()
            } else startService(Intent(this, OverlayService::class.java))
        }
        root.addView(show, margin(0, dp(8), 0, dp(18)))

        val note = label(
            "Как пользоваться\n• Включи службу и разреши отображение поверх приложений.\n• Покажи панель и нажми ⊕. Перетащи зелёный маркер в нужное место и отпусти палец — точка сохранится автоматически.\n• Tap — короткое нажатие с выбранным интервалом. Hold — удержание в выбранной точке до «Пауза» или «Стоп».\n• В плавающей панели можно переключать Tap и Hold; стрелки < и > меняют интервал, а удержание стрелки ускоряет изменение.\n\nAndroid может ограничивать автоматизацию в некоторых приложениях. Используй функцию только там, где это разрешено.",
            14f
        )
        note.setTextColor(0xFFB7B7C8.toInt())
        root.addView(note)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun margin(l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(l, t, r, b)
        }

    private fun button(text: String) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        setTextColor(-1)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6650C8.toInt()))
    }
}
