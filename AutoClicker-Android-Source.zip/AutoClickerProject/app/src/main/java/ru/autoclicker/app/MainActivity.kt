package ru.autoclicker.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16,16,24)
        window.navigationBarColor = android.graphics.Color.rgb(16,16,24)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(android.graphics.Color.rgb(16,16,24))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(android.graphics.Color.WHITE)
        }
        val title = label("Auto Clicker", 28f)
        root.addView(title)
        val subtitle = label("Автоматизация нажатий • локально на устройстве", 13f)
        subtitle.setTextColor(0xFFB7B7C8.toInt()); root.addView(subtitle, margin(0, dp(6), 0, dp(22)))

        root.addView(label("Интервал между нажатиями (мс)"))
        val interval = EditText(this).apply {
            setSingleLine(true); inputType = 2; setText(prefs.getLong("interval", 500L).toString())
            setTextColor(-1); setHintTextColor(0xFF777788.toInt()); hint = "Например, 500"
            setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(0xFF242432.toInt())
        }
        root.addView(interval, margin(0, dp(8), 0, dp(16)))
        root.addView(label("Количество нажатий (0 = без ограничения)"))
        val count = EditText(this).apply {
            setSingleLine(true); inputType = 2; setText(prefs.getLong("count", 0L).toString())
            setTextColor(-1); setHintTextColor(0xFF777788.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(0xFF242432.toInt())
        }
        root.addView(count, margin(0, dp(8), 0, dp(20)))

        val permission = button("1. Включить службу специальных возможностей")
        permission.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(permission, margin(0, 0, 0, dp(10)))
        val overlayPermission = button("2. Разрешить отображение поверх приложений")
        overlayPermission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else Toast.makeText(this, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
        }
        root.addView(overlayPermission, margin(0, 0, 0, dp(10)))
        val show = button("Показать плавающую панель")
        show.setOnClickListener {
            val i = interval.text.toString().toLongOrNull()?.coerceIn(50, 60000) ?: 500L
            val c = count.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0L
            prefs.edit().putLong("interval", i).putLong("count", c).apply()
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Разреши отображение поверх приложений, затем вернись сюда", Toast.LENGTH_LONG).show()
            } else startService(Intent(this, OverlayService::class.java))
        }
        root.addView(show, margin(0, dp(8), 0, dp(18)))
        val note = label("Как пользоваться\n• Включи службу и разреши оверлей.\n• Покажи панель и нажми ⊕. Перетащи зелёный маркер в нужное место и отпусти палец — точка сохранится автоматически. Убедись, что второй счётчик стал 1.\n• «Старт» запускает последовательные нажатия; «Пауза» приостанавливает, «Стоп» останавливает.\n\nAndroid может ограничивать автоматизацию в некоторых приложениях. Используй функцию только там, где это разрешено.", 14f)
        note.setTextColor(0xFFB7B7C8.toInt()); root.addView(note)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }
    private fun margin(l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(l,t,r,b) }
    private fun button(text: String) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 14f; setTextColor(-1)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6650C8.toInt()))
    }
}
