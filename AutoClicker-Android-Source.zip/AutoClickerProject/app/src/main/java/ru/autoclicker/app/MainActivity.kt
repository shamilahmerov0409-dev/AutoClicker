package ru.autoclicker.app

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private var selectedInterval = 500
    private lateinit var intervalValue: TextView
    private lateinit var count: EditText
    private val intervalRepeatHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 16, 24)
        window.navigationBarColor = android.graphics.Color.rgb(16, 16, 24)
        selectedInterval = prefs.getLong("interval", 500L).toInt().coerceIn(1, 1000)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(android.graphics.Color.rgb(16, 16, 24))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(android.graphics.Color.WHITE)
        }
        root.addView(label("Auto Clicker", 28f))
        val subtitle = label("Автоматизация нажатий • локально на устройстве", 13f)
        subtitle.setTextColor(0xFFB7B7C8.toInt())
        root.addView(subtitle, margin(0, dp(6), 0, dp(22)))

        root.addView(label("Интервал между нажатиями (мс)"))
        val intervalRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF242432.toInt()); cornerRadius = dp(8).toFloat()
            }
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val minus = smallButton("‹")
        intervalValue = TextView(this).apply {
            textSize = 22f; gravity = Gravity.CENTER; setTextColor(-1)
            text = "$selectedInterval мс"
        }
        val plus = smallButton("›")
        intervalRow.addView(minus, LinearLayout.LayoutParams(dp(48), dp(48)))
        intervalRow.addView(intervalValue, LinearLayout.LayoutParams(0, dp(48), 1f))
        intervalRow.addView(plus, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(intervalRow, margin(0, dp(8), 0, dp(16)))
        // A short tap changes by 1 ms. Holding an arrow progressively increases
        // both the step size and repeat speed, so long adjustments stay practical.
        bindIntervalRepeat(minus, direction = -1)
        bindIntervalRepeat(plus, direction = 1)

        root.addView(label("Количество нажатий (0 = без ограничения)"))
        count = EditText(this).apply {
            setSingleLine(true); inputType = 2
            setText(prefs.getLong("count", 0L).coerceAtLeast(0).toString())
            setTextColor(-1); setHintTextColor(0xFF777788.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(0xFF242432.toInt())
        }
        root.addView(count, margin(0, dp(8), 0, dp(16)))

        val save = button("Сохранить настройки")
        save.setOnClickListener { saveSettings(showToast = true) }
        root.addView(save, margin(0, 0, 0, dp(10)))

        val permission = button("1. Включить службу специальных возможностей")
        permission.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(permission, margin(0, 0, 0, dp(10)))
        val overlayPermission = button("2. Разрешить отображение поверх приложений")
        overlayPermission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else Toast.makeText(this, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
        }
        root.addView(overlayPermission, margin(0, 0, 0, dp(10)))
        val show = button("Показать плавающую панель")
        show.setOnClickListener {
            saveSettings(showToast = false)
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Разреши отображение поверх приложений, затем вернись сюда", Toast.LENGTH_LONG).show()
            } else startService(Intent(this, OverlayService::class.java))
        }
        root.addView(show, margin(0, dp(8), 0, dp(18)))
        val note = label("Как пользоваться\n• Включи службу и разреши отображение поверх приложений.\n• Нажми ⊕ на панели, перетащи прицел и коснись его, чтобы сохранить точку.\n• Старт запускает нажатия, пауза временно приостанавливает, стоп останавливает.\n• Интервал выбирается стрелками от 1 до 1000 мс. Не все приложения допускают автоматизацию.", 14f)
        note.setTextColor(0xFFB7B7C8.toInt()); root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun bindIntervalRepeat(button: View, direction: Int) {
        var pressedAt = 0L
        var holding = false
        val repeat = object : Runnable {
            override fun run() {
                if (!holding) return
                val heldMs = SystemClock.uptimeMillis() - pressedAt
                val step = when {
                    heldMs >= 2500L -> 25
                    heldMs >= 1600L -> 10
                    heldMs >= 850L -> 5
                    else -> 1
                }
                setInterval(selectedInterval + direction * step)
                val delay = when {
                    heldMs >= 2500L -> 35L
                    heldMs >= 1600L -> 50L
                    heldMs >= 850L -> 75L
                    else -> 110L
                }
                intervalRepeatHandler.postDelayed(this, delay)
            }
        }

        button.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pressedAt = SystemClock.uptimeMillis()
                    holding = true
                    view.isPressed = true
                    intervalRepeatHandler.removeCallbacks(repeat)
                    setInterval(selectedInterval + direction)
                    intervalRepeatHandler.postDelayed(repeat, 320L)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    holding = false
                    view.isPressed = false
                    intervalRepeatHandler.removeCallbacks(repeat)
                    true
                }
                else -> true
            }
        }
    }

    private fun setInterval(value: Int) {
        selectedInterval = value.coerceIn(1, 1000)
        intervalValue.text = "$selectedInterval мс"
    }

    private fun saveSettings(showToast: Boolean) {
        val tapsLimit = count.text.toString().toLongOrNull()?.coerceAtLeast(0L) ?: 0L
        prefs.edit().putLong("interval", selectedInterval.toLong()).putLong("count", tapsLimit).apply()
        if (showToast) Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show()
    }

    private fun margin(l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(l, t, r, b) }

    private fun smallButton(text: String) = TextView(this).apply {
        this.text = text; textSize = 30f; gravity = Gravity.CENTER; setTextColor(-1)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(0xFF6650C8.toInt()); cornerRadius = dp(8).toFloat()
        }
        isClickable = true
    }

    override fun onDestroy() {
        intervalRepeatHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun button(text: String) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 14f; setTextColor(-1)
        backgroundTintList = ColorStateList.valueOf(0xFF6650C8.toInt())
    }
}
