package ru.autoclicker.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean

class ClickAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        OverlayService.accessibilityDisconnected()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        OverlayService.accessibilityConnected()
    }

    /**
     * Returns false if Android rejected dispatch immediately. The callback is still
     * invoked exactly once, so the overlay loop cannot become permanently stuck.
     */
    fun tap(x: Float, y: Float, done: ((Boolean) -> Unit)? = null): Boolean {
        val completed = AtomicBoolean(false)
        fun finish(success: Boolean) {
            if (!completed.compareAndSet(false, true)) return
            done?.let { callback ->
                if (Looper.myLooper() == Looper.getMainLooper()) callback(success)
                else Handler(Looper.getMainLooper()).post { callback(success) }
            }
        }

        return try {
            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    finish(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    finish(false)
                }
            }, null)
            if (!accepted) finish(false)
            accepted
        } catch (_: Exception) {
            finish(false)
            false
        }
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
            OverlayService.accessibilityDisconnected()
        }
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: ClickAccessibilityService? = null
    }
}
