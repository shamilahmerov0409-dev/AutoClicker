package ru.autoclicker.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean

class ClickAccessibilityService : AccessibilityService() {
    @Volatile private var holding = false
    @Volatile private var holdStroke: GestureDescription.StrokeDescription? = null
    @Volatile private var holdX = 0f
    @Volatile private var holdY = 0f
    @Volatile private var holdDone: ((Boolean) -> Unit)? = null
    @Volatile private var holdReverse = false
    @Volatile private var holdGeneration = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        releaseHold()
        OverlayService.stopForAccessibilityInterrupt()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        OverlayService.refreshAccessibilityStatus()
    }

    /** A normal short tap. The callback is guaranteed to run once. */
    fun tap(x: Float, y: Float, done: ((Boolean) -> Unit)? = null): Boolean {
        val completed = AtomicBoolean(false)
        fun finish(success: Boolean) {
            if (!completed.compareAndSet(false, true)) return
            done?.let { callback ->
                if (Looper.myLooper() == Looper.getMainLooper()) callback(success)
                else Handler(Looper.getMainLooper()).post { callback(success) }
            }
        }

        return try {
            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) = finish(true)
                override fun onCancelled(gestureDescription: GestureDescription?) = finish(false)
            }, null)
            if (!accepted) finish(false)
            accepted
        } catch (_: Exception) {
            finish(false)
            false
        }
    }

    /**
     * Starts a continuous finger-down gesture at (x, y). Android limits an individual
     * gesture segment to 60 seconds, so successful segments are continued seamlessly.
     * The callback runs only after the hold ends or Android cancels it.
     */
    fun hold(x: Float, y: Float, done: ((Boolean) -> Unit)? = null): Boolean {
        if (holding) releaseHold()
        holdGeneration++
        holdX = x
        holdY = y
        holdDone = done
        holdReverse = false
        holding = true
        return dispatchHoldSegment(null, holdGeneration)
    }

    private fun dispatchHoldSegment(previous: GestureDescription.StrokeDescription?, generation: Long): Boolean {
        if (!holding || generation != holdGeneration) return false
        return try {
            val startX = if (holdReverse) holdX + 0.1f else holdX
            val endX = if (holdReverse) holdX else holdX + 0.1f
            val path = Path().apply {
                moveTo(startX, holdY)
                lineTo(endX, holdY)
            }
            val stroke = if (previous == null) {
                GestureDescription.StrokeDescription(path, 0, 1_000L, true)
            } else {
                previous.continueStroke(path, 0, 1_000L, true)
            }
            holdStroke = stroke
            val accepted = dispatchGesture(strokeGesture(stroke), object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (generation != holdGeneration) return
                    if (holding) {
                        holdReverse = !holdReverse
                        dispatchHoldSegment(stroke, generation)
                    } else {
                        finishHold(true, generation)
                    }
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    finishHold(false, generation)
                }
            }, null)
            if (!accepted) finishHold(false, generation)
            accepted
        } catch (_: Exception) {
            finishHold(false, generation)
            false
        }
    }

    private fun strokeGesture(stroke: GestureDescription.StrokeDescription): GestureDescription =
        GestureDescription.Builder().addStroke(stroke).build()

    /**
     * AccessibilityService has no explicit cancelGesture API. Dispatching a tiny stroke
     * outside the display cancels the in-progress held gesture; the off-screen stroke
     * has no target to click. Its ACTION_CANCEL releases the held pointer without
     * intentionally tapping the selected target.
     */
    fun releaseHold() {
        if (!holding) return
        holding = false
        try {
            val path = Path().apply {
                moveTo(-10_000f, -10_000f)
                lineTo(-9_999f, -10_000f)
            }
            val cancelGesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 1L))
                .build()
            dispatchGesture(cancelGesture, null, null)
        } catch (_: Exception) {
            // If Android rejects cancellation, the active segment ends at its 1-second boundary.
        }
    }

    private fun finishHold(success: Boolean, generation: Long) {
        if (generation != holdGeneration) return
        holding = false
        holdStroke = null
        val callback = holdDone
        holdDone = null
        callback?.let {
            if (Looper.myLooper() == Looper.getMainLooper()) it(success)
            else Handler(Looper.getMainLooper()).post { it(success) }
        }
    }

    override fun onDestroy() {
        releaseHold()
        if (instance === this) instance = null
        OverlayService.refreshAccessibilityStatus()
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: ClickAccessibilityService? = null
    }
}
