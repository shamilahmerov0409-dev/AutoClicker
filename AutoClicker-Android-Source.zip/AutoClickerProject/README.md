# Auto Clicker (Android / Kotlin)

Русскоязычный минималистичный Android-проект автокликера. Автоматизация выполняется через `AccessibilityService.dispatchGesture`; плавающая панель использует разрешение отображения поверх других приложений. Настройки интервала и лимита хранятся локально.

## Сборка APK через GitHub Actions с телефона
Самый простой способ с телефона: загрузить ZIP проекта в корень репозитория, затем создать workflow-файл через сайт GitHub.

1. Создайте **публичный** репозиторий GitHub. Публичный репозиторий позволяет использовать стандартные GitHub-hosted runners бесплатно.
2. Загрузите файл `AutoClicker-Android-Source.zip` в корень репозитория через **Add file → Upload files**. Не распаковывайте архив.
3. В репозитории нажмите **Add file → Create new file**. В поле имени укажите `.github/workflows/build-apk.yml`.
4. Вставьте YAML workflow из файла `.github/workflows/build-apk.yml` внутри архива проекта. Закоммитьте файл в ветку `main`.
5. Откройте вкладку **Actions**. Если GitHub попросит разрешить workflows, нажмите разрешение. Выберите **Build Auto Clicker APK** → **Run workflow** → **Run workflow**.
6. Дождитесь завершения. Откройте запуск workflow, найдите **Artifacts** и скачайте `AutoClicker-debug-apk`.
7. Распакуйте ZIP артефакта. Внутри будет `app-debug.apk`.

## Установка и разрешения
Установите APK, затем откройте приложение. Включите службу Auto Clicker в настройках специальных возможностей и разрешите отображение поверх приложений. Покажите плавающую панель. Нажмите «Точка +», перетащите маркер и нажмите его, чтобы сохранить координату. Кнопки панели запускают, приостанавливают и останавливают последовательность.

## Ограничения и безопасность
- Это debug APK, а не релизная сборка для публикации в магазине.
- Проект не был собран в этой среде; используйте GitHub Actions, чтобы выполнить фактическую компиляцию. При ошибке сборки пришлите лог.
- Проверяйте работу на своём устройстве и Android-версии. Система и отдельные приложения могут блокировать жесты автоматизации.
- Координаты выбираются перемещаемым маркером. Проверяйте координату перед запуском; не используйте автокликер там, где это запрещено правилами сервиса.
- Приложение не отправляет данные в сеть.


## Reliability and compact overlay update

This revision reduces the floating panel's button sizes and fixes gesture-dispatch handling:
- rejected/cancelled accessibility gestures report failure instead of leaving the click loop stuck;
- three consecutive rejected gestures stop the clicker and show a message;
- Start does not enqueue duplicate loops while already running;
- Stop invalidates in-flight callbacks so they cannot restart the loop or overwrite the reset counter;
- the target marker stays visible after saving a point, instead of disappearing on tap.

Build in GitHub Actions or with Gradle 8.9 and Android SDK platform/build-tools 35.


## Обновления интерфейса и управления
- Интервал выбирается стрелками от 1 до 1000 мс.
- Кнопка «Сохранить настройки» сохраняет интервал и лимит нажатий.
- Координаты маркера считываются через `getLocationOnScreen`, чтобы тап совпадал с визуальным центром прицела.
- Добавлен watchdog для ситуации, когда Android не возвращает callback жеста; поздние callback после остановки игнорируются.
- Кнопка «−» удаляет последнюю точку, а при удалении последней точки убирает маркер с экрана.

Сборку и поведение на физическом устройстве необходимо проверить через GitHub Actions и на самом телефоне: этот архив содержит исходники, не готовый APK.
